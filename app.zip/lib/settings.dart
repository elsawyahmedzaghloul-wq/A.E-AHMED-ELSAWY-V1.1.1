import 'package:flutter/material.dart';

import 'core.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _svc;
  late final TextEditingController _tpl;
  late final TextEditingController _pub;
  late final TextEditingController _prv;

  @override
  void initState() {
    super.initState();
    final p = Store.I.prefs;
    _svc = TextEditingController(text: p.getString('ejs_service') ?? '');
    _tpl = TextEditingController(text: p.getString('ejs_template') ?? '');
    _pub = TextEditingController(text: p.getString('ejs_public') ?? '');
    _prv = TextEditingController(text: p.getString('ejs_private') ?? '');
  }

  @override
  void dispose() {
    _svc.dispose();
    _tpl.dispose();
    _pub.dispose();
    _prv.dispose();
    super.dispose();
  }

  // ----- الرمز -----
  Future<String?> _askNewPin() async {
    final a = await promptText(context,
        title: 'الرمز الجديد',
        label: '4 إلى 8 أرقام',
        obscure: true,
        number: true,
        okText: 'التالي');
    if (a == null) return null;
    final pin = normDigits(a.trim());
    if (pin.length < 4 || pin.length > 8) {
      if (mounted) toast(context, 'الرمز يجب أن يكون من 4 إلى 8 أرقام');
      return null;
    }
    if (!mounted) return null;
    final b = await promptText(context,
        title: 'تأكيد الرمز',
        label: 'أعد كتابة الرمز',
        obscure: true,
        number: true);
    if (b == null) return null;
    if (normDigits(b.trim()) != pin) {
      if (mounted) toast(context, 'الرمزان غير متطابقين');
      return null;
    }
    return pin;
  }

  Future<bool> _askCurrentPin() async {
    final cur = await promptText(context,
        title: 'الرمز الحالي',
        label: 'أدخل الرمز الحالي',
        obscure: true,
        number: true,
        okText: 'تأكيد');
    if (cur == null) return false;
    final ok = Store.I.checkPin(normDigits(cur.trim()));
    if (!ok && mounted) toast(context, 'الرمز الحالي غير صحيح');
    return ok;
  }

  Future<void> _setOrChangePin() async {
    if (Store.I.hasPin && !await _askCurrentPin()) return;
    final pin = await _askNewPin();
    if (pin == null) return;
    await Store.I.setPin(pin);
    if (!mounted) return;
    setState(() {});
    toast(context, 'تم حفظ الرمز');
  }

  Future<void> _removePin() async {
    if (!await _askCurrentPin()) return;
    await Store.I.removePin();
    if (!mounted) return;
    setState(() {});
    toast(context, 'تم إلغاء قفل الرمز');
  }

  // ----- الاسترجاع -----
  Future<void> _setEmail() async {
    final t = await promptText(context,
        title: 'بريد الاسترجاع',
        label: 'البريد الإلكتروني',
        initial: Store.I.email);
    if (t == null) return;
    final e = t.trim();
    if (e.isNotEmpty && !e.contains('@')) {
      if (mounted) toast(context, 'بريد غير صالح');
      return;
    }
    await Store.I.setEmail(e);
    if (mounted) setState(() {});
  }

  Future<void> _setQuestion() async {
    final q = await promptText(context,
        title: 'سؤال الأمان',
        label: 'اكتب السؤال (مثال: اسم أول مدرسة؟)',
        initial: Store.I.question,
        okText: 'التالي');
    if (q == null || q.trim().isEmpty) return;
    if (!mounted) return;
    final a = await promptText(context, title: 'الإجابة', label: 'اكتب الإجابة');
    if (a == null || a.trim().isEmpty) return;
    await Store.I.setQuestion(q, a);
    if (mounted) setState(() {});
  }

  // ----- إعدادات EmailJS -----
  Future<void> _saveMailCfg() async {
    final p = Store.I.prefs;
    await p.setString('ejs_service', _svc.text.trim());
    await p.setString('ejs_template', _tpl.text.trim());
    await p.setString('ejs_public', _pub.text.trim());
    await p.setString('ejs_private', _prv.text.trim());
    if (mounted) toast(context, 'تم حفظ إعدادات البريد');
  }

  Future<void> _testMail() async {
    await _saveMailCfg();
    if (Store.I.email.isEmpty) {
      if (mounted) toast(context, 'أضف بريد الاسترجاع أولًا');
      return;
    }
    final err = await Mailer.sendCode(Store.I.email, '123456 (رسالة اختبار)');
    if (!mounted) return;
    toast(context, err ?? 'تم إرسال رسالة اختبار — افحص بريدك');
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.I;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          const _Header('الحماية'),
          ListTile(
            leading: const Icon(Icons.lock),
            title: Text(s.hasPin ? 'تغيير الرمز السري' : 'تفعيل الرمز السري'),
            subtitle: Text(s.hasPin ? 'الرمز مفعّل' : 'التطبيق غير محمي برمز حاليًا'),
            onTap: _setOrChangePin,
          ),
          if (s.hasPin)
            ListTile(
              leading: const Icon(Icons.lock_open),
              title: const Text('إلغاء الرمز السري'),
              onTap: _removePin,
            ),
          const _Header('استرجاع الرمز عند النسيان'),
          ListTile(
            leading: const Icon(Icons.email),
            title: const Text('بريد الاسترجاع'),
            subtitle: Text(s.email.isEmpty ? 'غير مضاف' : s.email),
            onTap: _setEmail,
          ),
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('سؤال الأمان (يعمل بدون إنترنت)'),
            subtitle: Text(s.question.isEmpty ? 'غير مضاف' : s.question),
            onTap: _setQuestion,
          ),
          ExpansionTile(
            leading: const Icon(Icons.settings_applications),
            title: const Text('إعدادات إرسال البريد (EmailJS)'),
            subtitle: Text(Mailer.configured ? 'مضبوطة' : 'غير مضبوطة'),
            childrenPadding: const EdgeInsets.all(16),
            children: [
              const Text(
                'لإرسال رمز الاسترجاع على بريدك يحتاج التطبيق إلى خدمة بريد مجانية (EmailJS). '
                'أدخل البيانات الأربعة من حسابك هناك (الخطوات في دليل الاستخدام).',
              ),
              const SizedBox(height: 12),
              _field(_svc, 'Service ID'),
              _field(_tpl, 'Template ID'),
              _field(_pub, 'Public Key'),
              _field(_prv, 'Private Key (Access Token)'),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: FilledButton(
                        onPressed: _saveMailCfg, child: const Text('حفظ')),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                        onPressed: _testMail, child: const Text('إرسال اختبار')),
                  ),
                ],
              ),
            ],
          ),
          const _Header('التخزين'),
          ListTile(
            leading: const Icon(Icons.folder),
            title: const Text('مكان حفظ الصور داخل التطبيق'),
            subtitle: Directionality(
              textDirection: TextDirection.ltr,
              child: Text(s.root.path),
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'الصور محفوظة في مساحة التطبيق الخاصة (متوافقة مع Scoped Storage في أندرويد 10–15+ دون أذونات تخزين). '
              'للحصول على نسخة خارج التطبيق استخدم زر المشاركة داخل صفحة المنتج (يُنشئ ملف ZIP).',
              style: TextStyle(color: Colors.black54),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: c,
          decoration: InputDecoration(
              labelText: label, border: const OutlineInputBorder()),
        ),
      );
}

class _Header extends StatelessWidget {
  const _Header(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(text,
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary)),
      );
}
