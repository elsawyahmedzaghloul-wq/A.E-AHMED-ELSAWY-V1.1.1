import 'dart:math';

import 'package:flutter/material.dart';

import 'core.dart';

/// يغلّف الشاشة الرئيسية: يعرض شاشة الرمز عند الفتح وبعد غياب التطبيق 3 دقائق.
class LockGate extends StatefulWidget {
  const LockGate({super.key, required this.child});
  final Widget child;

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  bool _locked = Store.I.hasPin;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final t = _pausedAt;
      _pausedAt = null;
      if (t != null &&
          Store.I.hasPin &&
          DateTime.now().difference(t) > const Duration(minutes: 3)) {
        navKey.currentState?.popUntil((r) => r.isFirst);
        setState(() => _locked = true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_locked)
          Positioned.fill(
            child: LockScreen(onUnlocked: () => setState(() => _locked = false)),
          ),
      ],
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key, required this.onUnlocked});
  final VoidCallback onUnlocked;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _c = TextEditingController();
  String? _err;

  void _try() {
    if (Store.I.checkPin(normDigits(_c.text.trim()))) {
      widget.onUnlocked();
    } else {
      setState(() {
        _err = 'الرمز غير صحيح';
        _c.clear();
      });
    }
  }

  Future<void> _forgot() async {
    final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => const ForgotPinScreen()));
    if (ok == true) widget.onUnlocked();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock, size: 64, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 12),
                Text('أدخل الرمز السري',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                SizedBox(
                  width: 220,
                  child: TextField(
                    controller: _c,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    maxLength: 8,
                    style: const TextStyle(fontSize: 24, letterSpacing: 8),
                    onSubmitted: (_) => _try(),
                    decoration: InputDecoration(
                      errorText: _err,
                      counterText: '',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton(onPressed: _try, child: const Text('فتح')),
                TextButton(onPressed: _forgot, child: const Text('نسيت الرمز؟')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ForgotPinScreen extends StatefulWidget {
  const ForgotPinScreen({super.key});

  @override
  State<ForgotPinScreen> createState() => _ForgotPinScreenState();
}

class _ForgotPinScreenState extends State<ForgotPinScreen> {
  final _codeC = TextEditingController();
  final _ansC = TextEditingController();
  final _p1 = TextEditingController();
  final _p2 = TextEditingController();
  String? _sentCode;
  DateTime? _sentAt;
  bool _sending = false;
  bool _verified = false;
  String? _msg;

  Future<void> _sendCode() async {
    final code = (100000 + Random.secure().nextInt(900000)).toString();
    setState(() {
      _sending = true;
      _msg = null;
    });
    final err = await Mailer.sendCode(Store.I.email, code);
    if (!mounted) return;
    setState(() {
      _sending = false;
      if (err == null) {
        _sentCode = code;
        _sentAt = DateTime.now();
        _msg = 'تم إرسال الرمز إلى ${Store.I.email} — صالح 10 دقائق.';
      } else {
        _msg = err;
      }
    });
  }

  void _verifyCode() {
    final ok = _sentCode != null &&
        _sentAt != null &&
        DateTime.now().difference(_sentAt!) < const Duration(minutes: 10) &&
        normDigits(_codeC.text.trim()) == _sentCode;
    setState(() {
      _verified = ok;
      if (!ok) _msg = 'رمز التحقق غير صحيح أو انتهت صلاحيته';
    });
  }

  void _verifyAnswer() {
    final ok = Store.I.checkAnswer(_ansC.text);
    setState(() {
      _verified = ok;
      if (!ok) _msg = 'الإجابة غير صحيحة';
    });
  }

  Future<void> _saveNew() async {
    final a = normDigits(_p1.text.trim());
    final b = normDigits(_p2.text.trim());
    if (a.length < 4) {
      setState(() => _msg = 'الرمز يجب ألا يقل عن 4 أرقام');
      return;
    }
    if (a != b) {
      setState(() => _msg = 'الرمزان غير متطابقين');
      return;
    }
    await Store.I.setPin(a);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _codeC.dispose();
    _ansC.dispose();
    _p1.dispose();
    _p2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = Store.I;
    final children = <Widget>[];

    if (_verified) {
      children.addAll([
        const Text('تم التحقق ✓ — اختر رمزًا جديدًا:',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          controller: _p1,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(
              labelText: 'الرمز الجديد', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _p2,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(
              labelText: 'تأكيد الرمز الجديد', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 8),
        FilledButton(onPressed: _saveNew, child: const Text('حفظ الرمز الجديد')),
      ]);
    } else {
      if (s.email.isEmpty && s.question.isEmpty) {
        children.add(const Text(
            'لا توجد وسيلة استرجاع محفوظة (لا بريد ولا سؤال أمان).\nيمكنك إعادة تثبيت التطبيق، لكن ستفقد البيانات المحفوظة.'));
      }
      if (s.email.isNotEmpty) {
        children.add(Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('الاسترجاع عبر البريد (يحتاج إنترنت)',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: _sending ? null : _sendCode,
                  icon: const Icon(Icons.email),
                  label: Text(_sending ? 'جارٍ الإرسال...' : 'إرسال رمز إلى ${s.email}'),
                ),
                if (_sentCode != null) ...[
                  const SizedBox(height: 8),
                  TextField(
                    controller: _codeC,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        labelText: 'رمز التحقق المكوّن من 6 أرقام',
                        border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 8),
                  FilledButton(onPressed: _verifyCode, child: const Text('تحقق')),
                ],
              ],
            ),
          ),
        ));
      }
      if (s.question.isNotEmpty) {
        children.add(Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('الاسترجاع بسؤال الأمان (بدون إنترنت)',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(s.question),
                const SizedBox(height: 8),
                TextField(
                  controller: _ansC,
                  decoration: const InputDecoration(
                      labelText: 'الإجابة', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 8),
                FilledButton(onPressed: _verifyAnswer, child: const Text('تحقق')),
              ],
            ),
          ),
        ));
      }
    }

    if (_msg != null) {
      children.add(Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Text(_msg!, style: const TextStyle(color: Colors.deepOrange)),
      ));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('استرجاع الرمز')),
      body: ListView(padding: const EdgeInsets.all(16), children: children),
    );
  }
}
