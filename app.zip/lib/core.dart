import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:archive/archive_io.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

// ───────────────────────── التاريخ والورديات ─────────────────────────

const dayNamesEn = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
];
const dayNamesAr = [
  'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'
];

String two(int n) => n.toString().padLeft(2, '0');
String ymd(DateTime d) => '${d.year}-${two(d.month)}-${two(d.day)}';
String dayEn(DateTime d) => dayNamesEn[d.weekday - 1];
String dayAr(DateTime d) => dayNamesAr[d.weekday - 1];
String dayArFromEn(String en) {
  final i = dayNamesEn.indexOf(en);
  return i < 0 ? en : dayNamesAr[i];
}

/// الأولى 8→16 (A) ، الثانية 16→23 (B) ، الثالثة 23→8 (C)
String autoShiftCode(DateTime t) {
  final h = t.hour;
  if (h >= 8 && h < 16) return 'A';
  if (h >= 16 && h < 23) return 'B';
  return 'C';
}

/// تاريخ الوردية = تاريخ يوم بدايتها.
/// الوردية الثالثة بعد منتصف الليل (0:00–7:59) تُحسب على اليوم السابق.
DateTime shiftDate(String code, DateTime now) {
  if (code == 'C' && now.hour < 8) {
    return DateTime(now.year, now.month, now.day - 1);
  }
  return DateTime(now.year, now.month, now.day);
}

String shiftTitleAr(String c) {
  switch (c) {
    case 'A':
      return 'الوردية الأولى (Shift A)';
    case 'B':
      return 'الوردية الثانية (Shift B)';
    default:
      return 'الوردية الثالثة (Shift C)';
  }
}

String shiftRangeAr(String c) {
  switch (c) {
    case 'A':
      return 'من 8:00 ص إلى 4:00 م';
    case 'B':
      return 'من 4:00 م إلى 11:00 م';
    default:
      return 'من 11:00 م إلى 8:00 ص (تُسجَّل بتاريخ يوم بدايتها)';
  }
}

// ───────────────────────── أدوات عامة ─────────────────────────

String normDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var t = s;
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(ar[i], '$i');
  }
  return t;
}

double? parseNum(String s) {
  var t = normDigits(s.trim());
  if (t.isEmpty) return null;
  t = t.replaceAll('٫', '.').replaceAll(',', '.').replaceAll('٬', '');
  return double.tryParse(t);
}

String hashOf(String salt, String v) =>
    sha256.convert(utf8.encode('$salt::$v')).toString();

Future<String?> promptText(
  BuildContext context, {
  required String title,
  String label = '',
  String initial = '',
  bool obscure = false,
  bool number = false,
  int maxLines = 1,
  String okText = 'حفظ',
}) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: c,
        autofocus: true,
        obscureText: obscure,
        maxLines: obscure ? 1 : maxLines,
        keyboardType: number
            ? TextInputType.number
            : (maxLines > 1 ? TextInputType.multiline : TextInputType.text),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text), child: Text(okText)),
      ],
    ),
  );
}

Future<bool> confirmDialog(BuildContext context, String title, String msg,
    {String okText = 'تأكيد'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(msg),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true), child: Text(okText)),
      ],
    ),
  );
  return r == true;
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<void> showShiftSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (ctx) {
      final s = Store.I;
      Widget tile(String? code, String title, String sub) => ListTile(
            leading: Icon(s.manualShift == code
                ? Icons.radio_button_checked
                : Icons.radio_button_off),
            title: Text(title),
            subtitle: Text(sub),
            onTap: () {
              s.setManualShift(code);
              Navigator.pop(ctx);
            },
          );
      return SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('اختيار الوردية',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            tile(null, 'تلقائي حسب ساعة الهاتف',
                'الآن: ${shiftTitleAr(autoShiftCode(DateTime.now()))}'),
            for (final c in ['A', 'B', 'C']) tile(c, shiftTitleAr(c), shiftRangeAr(c)),
          ],
        ),
      );
    },
  );
}

// ───────────────────────── النماذج ─────────────────────────

class Product {
  Product({
    required this.id,
    required this.name,
    required this.folder,
    this.notes = '',
    this.hasCover = false,
  });

  String id;
  String name;
  String folder;
  String notes;
  bool hasCover;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'folder': folder,
        'notes': notes,
        'hasCover': hasCover,
      };

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as String,
        name: j['name'] as String,
        folder: j['folder'] as String,
        notes: (j['notes'] ?? '') as String,
        hasCover: (j['hasCover'] ?? false) as bool,
      );
}

class PhotoGroup {
  PhotoGroup({
    required this.dir,
    required this.relDir,
    required this.date,
    required this.day,
    required this.shift,
    required this.files,
  });

  final Directory dir;
  final String relDir;
  final String date;
  final String day;
  final String shift;
  final List<File> files;

  String get shiftCode => shift.isEmpty ? '' : shift.substring(shift.length - 1);
}

// ───────────────────────── المخزن (بيانات + ملفات + أمان) ─────────────────────────

class Store extends ChangeNotifier {
  Store._();
  static final Store I = Store._();

  late Directory root;
  late File dataFile;
  late SharedPreferences prefs;

  List<Product> products = [];
  Map<String, String> notes = {};
  String? manualShift; // null = تلقائي

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    final docs = await getApplicationDocumentsDirectory();
    root = Directory(p.join(docs.path, 'QC'));
    if (!root.existsSync()) root.createSync(recursive: true);
    dataFile = File(p.join(docs.path, 'qc_data.json'));
    if (dataFile.existsSync()) {
      try {
        final j = jsonDecode(await dataFile.readAsString()) as Map<String, dynamic>;
        products = ((j['products'] ?? []) as List)
            .map((e) => Product.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        notes = Map<String, String>.from((j['notes'] ?? {}) as Map);
      } catch (_) {}
    }
  }

  Future<void> _save() async {
    await dataFile.writeAsString(jsonEncode({
      'products': products.map((e) => e.toJson()).toList(),
      'notes': notes,
    }));
    notifyListeners();
  }

  // ----- الوردية -----
  String get shiftCode => manualShift ?? autoShiftCode(DateTime.now());
  void setManualShift(String? c) {
    manualShift = c;
    notifyListeners();
  }

  /// المسار النسبي الذي ستُحفظ فيه الصورة الآن
  String destinationFor(Product pr) {
    final now = DateTime.now();
    final c = shiftCode;
    final d = shiftDate(c, now);
    return '${pr.folder}/${ymd(d)}/${dayEn(d)}/Shift_$c';
  }

  // ----- المنتجات -----
  String _uniqueFolder(String name, {String? except}) {
    var base = name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
    if (base.isEmpty) base = 'product';
    var f = base;
    var i = 2;
    while (products.any(
        (e) => e.folder.toLowerCase() == f.toLowerCase() && e.id != except)) {
      f = '${base}_$i';
      i++;
    }
    return f;
  }

  Future<Product> addProduct(String name, String notesText) async {
    final pr = Product(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name.trim(),
      folder: _uniqueFolder(name),
      notes: notesText.trim(),
    );
    Directory(p.join(root.path, pr.folder)).createSync(recursive: true);
    products.add(pr);
    await _save();
    return pr;
  }

  Future<void> updateProduct(Product pr, String name, String n) async {
    pr.name = name.trim();
    pr.notes = n.trim();
    await _save();
  }

  Future<void> deleteProduct(Product pr) async {
    final d = productDir(pr);
    if (d.existsSync()) d.deleteSync(recursive: true);
    notes.removeWhere((k, _) => k.startsWith('${pr.folder}/'));
    products.removeWhere((e) => e.id == pr.id);
    await _save();
  }

  Directory productDir(Product pr) => Directory(p.join(root.path, pr.folder));
  File coverFile(Product pr) => File(p.join(root.path, pr.folder, '_cover.jpg'));
  String relOf(String path) => p.relative(path, from: root.path);

  Future<void> setCover(Product pr, XFile x) async {
    productDir(pr).createSync(recursive: true);
    final target = coverFile(pr);
    await File(x.path).copy(target.path);
    await FileImage(target).evict();
    pr.hasCover = true;
    await _save();
  }

  // ----- الصور -----
  Future<File> savePhoto(Product pr, XFile x) async {
    final now = DateTime.now();
    final c = shiftCode;
    final d = shiftDate(c, now);
    final dir = Directory(
        p.join(root.path, pr.folder, ymd(d), dayEn(d), 'Shift_$c'));
    dir.createSync(recursive: true);
    final name =
        'IMG_${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}${two(now.second)}_${now.millisecond}.jpg';
    final out = await File(x.path).copy(p.join(dir.path, name));
    notifyListeners();
    return out;
  }

  List<PhotoGroup> groups(Product pr) {
    final res = <PhotoGroup>[];
    final pd = productDir(pr);
    if (!pd.existsSync()) return res;
    final dateRe = RegExp(r'^\d{4}-\d{2}-\d{2}$');
    for (final dEnt in pd.listSync().whereType<Directory>()) {
      final date = p.basename(dEnt.path);
      if (!dateRe.hasMatch(date)) continue;
      for (final dayEnt in dEnt.listSync().whereType<Directory>()) {
        for (final shEnt in dayEnt.listSync().whereType<Directory>()) {
          final files = shEnt
              .listSync()
              .whereType<File>()
              .where((f) => f.path.toLowerCase().endsWith('.jpg'))
              .toList()
            ..sort((a, b) => b.path.compareTo(a.path));
          if (files.isEmpty) continue;
          res.add(PhotoGroup(
            dir: shEnt,
            relDir: relOf(shEnt.path),
            date: date,
            day: p.basename(dayEnt.path),
            shift: p.basename(shEnt.path),
            files: files,
          ));
        }
      }
    }
    res.sort((a, b) {
      final c = b.date.compareTo(a.date);
      return c != 0 ? c : b.shift.compareTo(a.shift);
    });
    return res;
  }

  int photoCount(Product pr) =>
      groups(pr).fold<int>(0, (s, g) => s + g.files.length);

  Future<void> deletePhoto(File f) async {
    if (f.existsSync()) f.deleteSync();
    notes.remove(relOf(f.path));
    await _save();
  }

  // ----- الملاحظات (للصور وللدفعات/المجلدات) -----
  String noteFor(String rel) => notes[rel] ?? '';
  Future<void> setNote(String rel, String t) async {
    if (t.trim().isEmpty) {
      notes.remove(rel);
    } else {
      notes[rel] = t.trim();
    }
    await _save();
  }

  // ----- المشاركة -----
  Future<void> shareFile(File f, {String? text}) async {
    await Share.shareXFiles([XFile(f.path)], text: text);
  }

  Future<void> shareFolder(Directory d, String zipName, {String? text}) async {
    final tmp = await getTemporaryDirectory();
    final safe = zipName.replaceAll(RegExp(r'[\\/:*?"<>| ]'), '_');
    final out = p.join(tmp.path, '$safe.zip');
    final enc = ZipFileEncoder();
    await Future<void>.sync(() => enc.zipDirectory(d, filename: out));
    await Share.shareXFiles([XFile(out)], text: text);
  }

  // ----- الأمان -----
  bool get hasPin => prefs.getString('pinHash') != null;

  Future<void> setPin(String pin) async {
    final salt = Random.secure().nextInt(1 << 31).toString();
    await prefs.setString('pinSalt', salt);
    await prefs.setString('pinHash', hashOf(salt, pin));
    notifyListeners();
  }

  bool checkPin(String pin) =>
      hasPin &&
      hashOf(prefs.getString('pinSalt') ?? '', pin) == prefs.getString('pinHash');

  Future<void> removePin() async {
    await prefs.remove('pinHash');
    await prefs.remove('pinSalt');
    notifyListeners();
  }

  String get email => prefs.getString('email') ?? '';
  Future<void> setEmail(String e) async {
    await prefs.setString('email', e.trim());
    notifyListeners();
  }

  String get question => prefs.getString('question') ?? '';
  Future<void> setQuestion(String q, String answer) async {
    await prefs.setString('question', q.trim());
    await prefs.setString('answerHash', hashOf('ans', answer.trim().toLowerCase()));
    notifyListeners();
  }

  bool checkAnswer(String a) =>
      question.isNotEmpty &&
      hashOf('ans', a.trim().toLowerCase()) == prefs.getString('answerHash');
}

// ───────────────────────── إرسال رمز الاسترجاع بالبريد (EmailJS) ─────────────────────────

class Mailer {
  static bool get configured {
    final s = Store.I.prefs;
    return (s.getString('ejs_service') ?? '').isNotEmpty &&
        (s.getString('ejs_template') ?? '').isNotEmpty &&
        (s.getString('ejs_public') ?? '').isNotEmpty;
  }

  /// يرجع null عند النجاح، أو رسالة خطأ.
  static Future<String?> sendCode(String toEmail, String code) async {
    final s = Store.I.prefs;
    if (!configured) {
      return 'لم يتم ضبط إعدادات إرسال البريد بعد (الإعدادات ← إعدادات إرسال البريد).';
    }
    final body = <String, dynamic>{
      'service_id': s.getString('ejs_service'),
      'template_id': s.getString('ejs_template'),
      'user_id': s.getString('ejs_public'),
      'template_params': {'to_email': toEmail, 'code': code},
    };
    final priv = s.getString('ejs_private') ?? '';
    if (priv.isNotEmpty) body['accessToken'] = priv;
    try {
      final r = await http
          .post(
            Uri.parse('https://api.emailjs.com/api/v1.0/email/send'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 20));
      if (r.statusCode == 200) return null;
      return 'تعذّر الإرسال (${r.statusCode}): ${r.body}';
    } catch (_) {
      return 'تعذّر الاتصال بالإنترنت. تأكد من الاتصال ثم حاول مرة أخرى.';
    }
  }
}
