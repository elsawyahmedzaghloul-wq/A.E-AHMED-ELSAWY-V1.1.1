import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import 'core.dart';

class FieldDef {
  const FieldDef(this.key, this.label, this.unit, {this.initial = ''});
  final String key;
  final String label;
  final String unit;
  final String initial;
}

class ResultRow {
  const ResultRow(this.label, this.value, this.unit,
      {this.strong = false, this.isCheck = false});
  final String label;
  final double? value;
  final String unit;
  final bool strong;
  final bool isCheck; // صف "إجمالي التحقق" (يجب أن يساوي 100%)
}

typedef Compute = List<ResultRow> Function(double? Function(String key) v);

double? _div(double? a, double? b) =>
    (a == null || b == null || b == 0) ? null : a / b;
double? _mul(double? a, double? b) => (a == null || b == null) ? null : a * b;
double? _pct(double? a, double? b) {
  final r = _div(a, b);
  return r == null ? null : r * 100;
}

// ───────────────────────── المعادلات (مطابقة لملفي الإكسل) ─────────────────────────

/// ملف: نسبه_الكسر_اخر_تعديل.xlsx  — ورقة "حاسبة الكسر"
List<ResultRow> computeBreakage(double? Function(String) v) {
  final flour = _mul(v('doughs'), v('bag')); // B6 = B4*B5
  final bab = v('bab');
  final oven = v('oven');
  final pads = v('pads');
  final saw = v('saw');
  final belt = v('belt');
  final mach = v('mach');
  final totalBreak = (oven ?? 0) + (pads ?? 0) + (saw ?? 0) + (belt ?? 0) + (mach ?? 0);
  final cartonsW = _mul(v('cartons'), v('net')); // B18 = B16*B17
  final totalProd = cartonsW == null ? null : totalBreak + cartonsW; // B19 = B15+B18
  return [
    ResultRow('إجمالي وزن الدقيق', flour, 'كجم'),
    ResultRow('نسبة البابليز', _pct(bab, flour), '%'),
    ResultRow('نسبة كسر الفرن', _pct(oven, flour), '%'),
    ResultRow('إجمالي الكسر', totalBreak, 'كجم'),
    ResultRow('إجمالي وزن الكراتين', cartonsW, 'كجم'),
    ResultRow('إجمالي الإنتاج', totalProd, 'كجم', strong: true),
    ResultRow('نسبة كسر الحشايا', _pct(pads, totalProd), '%'),
    ResultRow('نسبة كسر المنشار', _pct(saw, totalProd), '%'),
    ResultRow('نسبة كسر السير', _pct(belt, totalProd), '%'),
    ResultRow('نسبة كسر المكن', _pct(mach, totalProd), '%'),
    ResultRow('إجمالي نسبة الكسر', _pct(totalBreak, totalProd), '%', strong: true),
    ResultRow('نسبة الهالك', _pct(v('waste'), totalProd), '%', strong: true),
  ];
}

/// ملف: نسبه_الاشتراك.xlsx — ورقة "بدون تغطيس"
List<ResultRow> computePlain(double? Function(String) v) {
  final sheets = v('sheets');
  final block = v('block');
  final pieces = v('pieces');
  // نسبة العجين = (B4*B6)/B5/B6
  final dough = (sheets == null || block == null || pieces == null || block == 0 || pieces == 0)
      ? null
      : ((sheets * pieces) / block) / pieces * 100;
  // نسبة الكريمة = ((B5-B4)*B6/B5)/B6
  final cream = (sheets == null || block == null || pieces == null || block == 0 || pieces == 0)
      ? null
      : (((block - sheets) * pieces) / block) / pieces * 100;
  final check = (dough == null || cream == null) ? null : dough + cream;
  return [
    ResultRow('نسبة العجين', dough, '%', strong: true),
    ResultRow('نسبة الكريمة', cream, '%', strong: true),
    ResultRow('إجمالي التحقق (يجب أن يساوي 100%)', check, '%', isCheck: true),
  ];
}

/// ملف: نسبه_الاشتراك.xlsx — ورقة "مغطس بالشوكولاتة"
List<ResultRow> computeChoc(double? Function(String) v) {
  final sheets = v('sheets');
  final block = v('block');
  final before = v('before');
  final after = v('after');
  final ok = sheets != null &&
      block != null &&
      before != null &&
      after != null &&
      block != 0 &&
      after != 0;
  // العجين = ((B4*B6)/B5)/B7
  final dough = ok ? (((sheets * before) / block) / after) * 100 : null;
  // الكريمة = (((B5-B4)*B6)/B5)/B7
  final cream = ok ? ((((block - sheets) * before) / block) / after) * 100 : null;
  // الشوكولاتة = (B7-B6)/B7
  final choc = ok ? ((after - before) / after) * 100 : null;
  final check = (dough == null || cream == null || choc == null)
      ? null
      : dough + cream + choc;
  return [
    ResultRow('نسبة العجين', dough, '%', strong: true),
    ResultRow('نسبة الكريمة', cream, '%', strong: true),
    ResultRow('نسبة الشوكولاتة', choc, '%', strong: true),
    ResultRow('إجمالي التحقق (يجب أن يساوي 100%)', check, '%', isCheck: true),
  ];
}

// ───────────────────────── الشاشة ─────────────────────────

class RatesScreen extends StatelessWidget {
  const RatesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('المعدلات'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'نسب الكسر (A.E)'),
              Tab(text: 'بدون تغطيس'),
              Tab(text: 'مغطس بالشوكولاتة'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            CalcPage(
              title: 'حساب نسب الكسر (A.E)',
              fields: [
                FieldDef('doughs', 'عدد العجنات', 'عجنة'),
                FieldDef('bag', 'وزن شكارة الدقيق', 'كجم', initial: '50'),
                FieldDef('bab', 'وزن البابليز', 'كجم'),
                FieldDef('oven', 'وزن كسر الفرن', 'كجم'),
                FieldDef('pads', 'وزن كسر الحشايا', 'كجم'),
                FieldDef('saw', 'وزن كسر المنشار', 'كجم'),
                FieldDef('belt', 'وزن كسر النفق (السير)', 'كجم'),
                FieldDef('mach', 'وزن كسر المكن', 'كجم'),
                FieldDef('cartons', 'عدد الكراتين المنتجة', 'كرتونة'),
                FieldDef('net', 'الوزن الصافي للكرتونة', 'كجم', initial: '3'),
                FieldDef('waste', 'وزن الهالك', 'كجم'),
              ],
              compute: computeBreakage,
            ),
            CalcPage(
              title: 'نسب المنتج (بدون تغطيس)',
              fields: [
                FieldDef('sheets', 'وزن الشيتات المستخدمة في البلوك الواحد', 'جرام', initial: '500'),
                FieldDef('block', 'وزن البلوك نفسه', 'جرام', initial: '2000'),
                FieldDef('pieces', 'عدد قطع البلوك', 'قطعة', initial: '40'),
              ],
              compute: computePlain,
            ),
            CalcPage(
              title: 'نسب المنتج (مغطس بالشوكولاتة)',
              fields: [
                FieldDef('sheets', 'وزن الشيتات المستخدمة في البلوك الواحد', 'جرام', initial: '220'),
                FieldDef('block', 'وزن البلوك نفسه', 'جرام', initial: '640'),
                FieldDef('before', 'وزن قطع البلوك قبل التغطيس', 'جرام', initial: '510'),
                FieldDef('after', 'وزن قطع البلوك بعد التغطيس', 'جرام', initial: '1008'),
              ],
              compute: computeChoc,
            ),
          ],
        ),
      ),
    );
  }
}

class CalcPage extends StatefulWidget {
  const CalcPage({
    super.key,
    required this.title,
    required this.fields,
    required this.compute,
  });

  final String title;
  final List<FieldDef> fields;
  final Compute compute;

  @override
  State<CalcPage> createState() => _CalcPageState();
}

class _CalcPageState extends State<CalcPage>
    with AutomaticKeepAliveClientMixin {
  late final Map<String, TextEditingController> _c = {
    for (final f in widget.fields) f.key: TextEditingController(text: f.initial)
  };

  @override
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  double? _v(String k) => parseNum(_c[k]?.text ?? '');

  String _fmt(ResultRow r) {
    final v = r.value;
    if (v == null) return '—';
    if (v.isNaN || v.isInfinite) return '—';
    return v == v.roundToDouble() && r.unit != '%'
        ? v.toStringAsFixed(0)
        : v.toStringAsFixed(2);
  }

  String _summary(List<ResultRow> rows) {
    final now = DateTime.now();
    final code = Store.I.shiftCode;
    final d = shiftDate(code, now);
    final b = StringBuffer()
      ..writeln(widget.title)
      ..writeln('التاريخ: ${ymd(d)} (${dayAr(d)})')
      ..writeln('الوردية: ${shiftTitleAr(code)}')
      ..writeln()
      ..writeln('المدخلات:');
    for (final f in widget.fields) {
      final t = _c[f.key]!.text.trim();
      if (t.isNotEmpty) b.writeln('• ${f.label}: $t ${f.unit}');
    }
    b
      ..writeln()
      ..writeln('النتائج:');
    for (final r in rows) {
      b.writeln('• ${r.label}: ${_fmt(r)} ${r.unit}');
    }
    return b.toString();
  }

  void _reset() {
    setState(() {
      for (final f in widget.fields) {
        _c[f.key]!.text = f.initial;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final rows = widget.compute(_v);
    final cs = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        for (final f in widget.fields)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: TextField(
              controller: _c[f.key],
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: f.label,
                suffixText: f.unit,
                border: const OutlineInputBorder(),
              ),
            ),
          ),
        const SizedBox(height: 4),
        Card(
          color: cs.surfaceContainerHighest,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                for (final r in rows) _row(r),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => Share.share(_summary(rows)),
                icon: const Icon(Icons.share),
                label: const Text('مشاركة الملخص'),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: _reset,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة'),
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _row(ResultRow r) {
    Color? color;
    Widget? icon;
    if (r.isCheck && r.value != null) {
      final good = (r.value! - 100).abs() < 0.01;
      color = good ? Colors.green.shade700 : Colors.red.shade700;
      icon = Icon(good ? Icons.check_circle : Icons.error, color: color, size: 20);
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          if (icon != null) ...[icon, const SizedBox(width: 6)],
          Expanded(
            child: Text(r.label,
                style: TextStyle(
                    fontWeight: r.strong ? FontWeight.bold : FontWeight.normal)),
          ),
          Text('${_fmt(r)} ${r.unit}',
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: r.strong ? 18 : 16,
                  fontWeight: FontWeight.bold,
                  color: color)),
        ],
      ),
    );
  }
}
