import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'core.dart';

Future<void> showProductEditor(BuildContext context, Product? pr) async {
  final nameC = TextEditingController(text: pr?.name ?? '');
  final notesC = TextEditingController(text: pr?.notes ?? '');
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(pr == null ? 'إضافة منتج' : 'تعديل المنتج'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameC,
              autofocus: true,
              decoration: const InputDecoration(
                  labelText: 'اسم المنتج (مثال: ويفر)',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: notesC,
              maxLines: 4,
              decoration: const InputDecoration(
                  labelText: 'المواصفات / ملاحظات',
                  border: OutlineInputBorder()),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
      ],
    ),
  );
  if (ok != true || nameC.text.trim().isEmpty) return;
  if (pr == null) {
    await Store.I.addProduct(nameC.text, notesC.text);
  } else {
    await Store.I.updateProduct(pr, nameC.text, notesC.text);
  }
}

class ProductThumb extends StatelessWidget {
  const ProductThumb(this.product, {super.key, this.size = 52});
  final Product product;
  final double size;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: product.hasCover
          ? Image.file(
              Store.I.coverFile(product),
              width: size,
              height: size,
              fit: BoxFit.cover,
              cacheWidth: 200,
              errorBuilder: (_, __, ___) => _ph(cs),
            )
          : _ph(cs),
    );
  }

  Widget _ph(ColorScheme cs) => Container(
        width: size,
        height: size,
        color: cs.secondaryContainer,
        child: Icon(Icons.inventory_2, color: cs.onSecondaryContainer),
      );
}

// ───────────────────────── قائمة المنتجات ─────────────────────────

class ProductsScreen extends StatelessWidget {
  const ProductsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المنتجات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showProductEditor(context, null),
        icon: const Icon(Icons.add),
        label: const Text('منتج جديد'),
      ),
      body: ListenableBuilder(
        listenable: Store.I,
        builder: (context, _) {
          final list = Store.I.products;
          if (list.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'لا توجد منتجات بعد.\nاضغط "منتج جديد" لإضافة أول منتج (مثال: ويفر).',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final pr = list[i];
              return Card(
                child: ListTile(
                  leading: ProductThumb(pr),
                  title: Text(pr.name,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: pr.notes.isEmpty
                      ? null
                      : Text(pr.notes,
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'edit') {
                        await showProductEditor(context, pr);
                      } else if (v == 'delete') {
                        final ok = await confirmDialog(
                          context,
                          'حذف المنتج',
                          'سيتم حذف "${pr.name}" وجميع صوره نهائيًا. هل أنت متأكد؟',
                          okText: 'حذف',
                        );
                        if (ok) await Store.I.deleteProduct(pr);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('تعديل')),
                      PopupMenuItem(value: 'delete', child: Text('حذف')),
                    ],
                  ),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ProductScreen(product: pr))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ───────────────────────── صفحة المنتج ─────────────────────────

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key, required this.product});
  final Product product;

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final _picker = ImagePicker();
  Product get pr => widget.product;

  Future<void> _shoot() async {
    try {
      final x = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 88,
        maxWidth: 2560,
      );
      if (x == null) return;
      final f = await Store.I.savePhoto(pr, x);
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
          content: Text('تم الحفظ ✓  ${Store.I.relOf(f.parent.path)}'),
          action: SnackBarAction(
              label: 'ملاحظة', onPressed: () => _notePhoto(f)),
        ));
    } catch (e) {
      if (!mounted) return;
      toast(context, 'تعذّر فتح الكاميرا: $e');
    }
  }

  Future<void> _pickCover() async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('التقاط صورة للمنتج'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('اختيار من المعرض'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null) return;
    try {
      final x = await _picker.pickImage(
          source: src, imageQuality: 85, maxWidth: 1600);
      if (x == null) return;
      await Store.I.setCover(pr, x);
    } catch (e) {
      if (!mounted) return;
      toast(context, 'تعذّر اختيار الصورة: $e');
    }
  }

  Future<void> _notePhoto(File f) async {
    final rel = Store.I.relOf(f.path);
    final t = await promptText(context,
        title: 'ملاحظة على الصورة',
        label: 'اكتب ملاحظتك',
        initial: Store.I.noteFor(rel),
        maxLines: 3);
    if (t != null) await Store.I.setNote(rel, t);
  }

  Future<void> _noteBatch(PhotoGroup g) async {
    final t = await promptText(context,
        title: 'ملاحظة على الدفعة / الوردية',
        label: '${g.date} • ${g.shift}',
        initial: Store.I.noteFor(g.relDir),
        maxLines: 3);
    if (t != null) await Store.I.setNote(g.relDir, t);
  }

  Future<void> _shareGroup(PhotoGroup g) async {
    try {
      final note = Store.I.noteFor(g.relDir);
      await Store.I.shareFolder(
        g.dir,
        '${pr.folder}_${g.date}_${g.shift}',
        text:
            '${pr.name} — ${g.date} (${dayArFromEn(g.day)}) — ${shiftTitleAr(g.shiftCode)}${note.isEmpty ? '' : '\nملاحظة: $note'}',
      );
    } catch (e) {
      if (mounted) toast(context, 'تعذّرت المشاركة: $e');
    }
  }

  Future<void> _shareAll() async {
    try {
      await Store.I.shareFolder(Store.I.productDir(pr), pr.folder,
          text: 'أرشيف صور ${pr.name}');
    } catch (e) {
      if (mounted) toast(context, 'تعذّرت المشاركة: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(pr.name),
        actions: [
          IconButton(
            tooltip: 'مشاركة كل الأرشيف',
            icon: const Icon(Icons.ios_share),
            onPressed: _shareAll,
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: Store.I,
        builder: (context, _) {
          final s = Store.I;
          final groups = s.groups(pr);
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              // صورة المنتج
              Card(
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: _pickCover,
                  child: AspectRatio(
                    aspectRatio: 16 / 9,
                    child: pr.hasCover
                        ? Image.file(s.coverFile(pr),
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                const Center(child: Icon(Icons.broken_image)))
                        : const Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.add_a_photo, size: 40),
                                SizedBox(height: 8),
                                Text('اضغط لإضافة صورة المنتج'),
                              ],
                            ),
                          ),
                  ),
                ),
              ),
              // المواصفات
              Card(
                child: ListTile(
                  title: const Text('المواصفات / الملاحظات',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(pr.notes.isEmpty ? 'لا توجد مواصفات' : pr.notes),
                  trailing: IconButton(
                    icon: const Icon(Icons.edit),
                    onPressed: () => showProductEditor(context, pr),
                  ),
                ),
              ),
              // وجهة الحفظ
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(shiftTitleAr(s.shiftCode),
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16)),
                          ),
                          TextButton.icon(
                            onPressed: () => showShiftSheet(context),
                            icon: const Icon(Icons.swap_horiz),
                            label: const Text('تغيير'),
                          ),
                        ],
                      ),
                      const Text('سيتم حفظ الصورة في:',
                          style: TextStyle(color: Colors.black54)),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(s.destinationFor(pr),
                            style: const TextStyle(fontFamily: 'monospace')),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: FilledButton.icon(
                          onPressed: _shoot,
                          icon: const Icon(Icons.photo_camera, size: 28),
                          label: const Text('تصوير الآن',
                              style: TextStyle(fontSize: 18)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(4, 12, 4, 4),
                child: Text('أرشيف الصور',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              if (groups.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('لا توجد صور محفوظة لهذا المنتج بعد.')),
                ),
              for (final g in groups) _groupView(context, g),
            ],
          );
        },
      ),
    );
  }

  Widget _groupView(BuildContext context, PhotoGroup g) {
    final batchNote = Store.I.noteFor(g.relDir);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${g.date} • ${dayArFromEn(g.day)} • ${shiftTitleAr(g.shiftCode)}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  tooltip: 'ملاحظة على الدفعة',
                  icon: const Icon(Icons.note_add),
                  onPressed: () => _noteBatch(g),
                ),
                IconButton(
                  tooltip: 'مشاركة الدفعة',
                  icon: const Icon(Icons.share),
                  onPressed: () => _shareGroup(g),
                ),
              ],
            ),
            if (batchNote.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text('📝 $batchNote'),
              ),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              children: [
                for (final f in g.files)
                  GestureDetector(
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PhotoScreen(file: f))),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(f, fit: BoxFit.cover, cacheWidth: 300),
                        if (Store.I.noteFor(Store.I.relOf(f.path)).isNotEmpty)
                          const Positioned(
                            top: 4,
                            right: 4,
                            child: Icon(Icons.sticky_note_2,
                                size: 20, color: Colors.amber),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── عرض صورة ─────────────────────────

class PhotoScreen extends StatelessWidget {
  const PhotoScreen({super.key, required this.file});
  final File file;

  @override
  Widget build(BuildContext context) {
    final rel = Store.I.relOf(file.path);
    return ListenableBuilder(
      listenable: Store.I,
      builder: (context, _) {
        final note = Store.I.noteFor(rel);
        return Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            actions: [
              IconButton(
                tooltip: 'ملاحظة',
                icon: const Icon(Icons.note_add),
                onPressed: () async {
                  final t = await promptText(context,
                      title: 'ملاحظة على الصورة',
                      label: 'اكتب ملاحظتك',
                      initial: note,
                      maxLines: 3);
                  if (t != null) await Store.I.setNote(rel, t);
                },
              ),
              IconButton(
                tooltip: 'مشاركة',
                icon: const Icon(Icons.share),
                onPressed: () => Store.I.shareFile(file,
                    text: note.isEmpty ? null : 'ملاحظة: $note'),
              ),
              IconButton(
                tooltip: 'حذف',
                icon: const Icon(Icons.delete),
                onPressed: () async {
                  final ok = await confirmDialog(
                      context, 'حذف الصورة', 'هل تريد حذف هذه الصورة نهائيًا؟',
                      okText: 'حذف');
                  if (ok) {
                    await Store.I.deletePhoto(file);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: InteractiveViewer(
                  child: Center(child: Image.file(file)),
                ),
              ),
              if (note.isNotEmpty)
                Container(
                  width: double.infinity,
                  color: Colors.black87,
                  padding: const EdgeInsets.all(12),
                  child: Text('📝 $note',
                      style: const TextStyle(color: Colors.white)),
                ),
            ],
          ),
        );
      },
    );
  }
}
